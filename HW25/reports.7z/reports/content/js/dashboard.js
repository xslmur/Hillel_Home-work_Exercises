/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 69.84521307089624, "KoPercent": 30.154786929103764};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.3237148862984903, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.01436265709156194, 500, 1500, "get API logs"], "isController": false}, {"data": [0.5, 500, 1500, "login at qauto2.forstudy.space"], "isController": false}, {"data": [0.66, 500, 1500, "get API logs-0"], "isController": false}, {"data": [1.0, 500, 1500, "get API logs-1"], "isController": false}, {"data": [0.37864583333333335, 500, 1500, "get car"], "isController": false}, {"data": [0.44477911646586343, 500, 1500, "del car"], "isController": false}, {"data": [0.22817460317460317, 500, 1500, "add car"], "isController": false}, {"data": [0.542110358180058, 500, 1500, "options request"], "isController": false}, {"data": [0.5563380281690141, 500, 1500, "cars list"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 5233, 1578, 30.154786929103764, 3222.376839289126, 50, 41216, 1946.0, 7771.6, 10113.0, 18167.94, 10.851578279424512, 4.719325754586985, 3.7523641595677617], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["get API logs", 1114, 1089, 97.75583482944344, 6275.515260323158, 236, 18609, 5355.5, 14270.0, 16435.75, 18245.799999999992, 2.3103357452906685, 0.9570406068986542, 0.7154300913453662], "isController": false}, {"data": ["login at qauto2.forstudy.space", 1, 0, 0.0, 1205.0, 1205, 1205, 1205.0, 1205.0, 1205.0, 1205.0, 0.8298755186721991, 0.5397432572614107, 0.27635503112033194], "isController": false}, {"data": ["get API logs-0", 25, 0, 0.0, 517.12, 178, 651, 621.0, 645.2, 649.8, 651.0, 18.96813353566009, 5.4829761001517445, 4.260420618361153], "isController": false}, {"data": ["get API logs-1", 25, 0, 0.0, 53.23999999999998, 50, 57, 54.0, 56.400000000000006, 57.0, 57.0, 33.15649867374005, 34.03074229111406, 7.188225298408488], "isController": false}, {"data": ["get car", 960, 347, 36.145833333333336, 1865.462499999999, 78, 24369, 589.0, 4250.0, 7056.95, 19480.95, 2.0160782238350845, 1.2319910629719932, 0.629716815824954], "isController": false}, {"data": ["del car", 996, 71, 7.128514056224899, 2644.438755020083, 68, 19930, 697.5, 7858.6, 9269.75, 16456.0, 2.0763712701930235, 0.6805825246829678, 0.7595755295684858], "isController": false}, {"data": ["add car", 1008, 71, 7.0436507936507935, 3756.307539682544, 156, 41216, 3068.5, 7678.200000000003, 9758.55, 23143.909999999945, 2.1146172920311654, 1.0824621747307428, 0.9416655128576283], "isController": false}, {"data": ["options request", 1033, 0, 0.0, 1389.0648596321403, 50, 6200, 852.0, 3648.4000000000005, 4776.3, 6178.66, 2.145731075295843, 0.6474911154945464, 0.6632829880188027], "isController": false}, {"data": ["cars list", 71, 0, 0.0, 2962.5774647887324, 66, 19474, 259.0, 12179.6, 12202.8, 19474.0, 0.28322283653654373, 0.15958943035311107, 0.08289363361934851], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["400/Bad Request", 71, 4.49936628643853, 1.3567743168354671], "isController": false}, {"data": ["500/Internal Server Error", 1089, 69.01140684410646, 20.810242690617237], "isController": false}, {"data": ["404/Not Found", 418, 26.489226869455006, 7.9877699216510605], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 5233, 1578, "500/Internal Server Error", 1089, "404/Not Found", 418, "400/Bad Request", 71, "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["get API logs", 1114, 1089, "500/Internal Server Error", 1089, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["get car", 960, 347, "404/Not Found", 347, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["del car", 996, 71, "404/Not Found", 71, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["add car", 1008, 71, "400/Bad Request", 71, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
